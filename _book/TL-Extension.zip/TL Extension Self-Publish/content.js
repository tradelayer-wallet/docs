// content.js
console.log("Content script loaded successfully!");
document.body.style.backgroundColor = "lightblue"; // Just for visual confirmation
