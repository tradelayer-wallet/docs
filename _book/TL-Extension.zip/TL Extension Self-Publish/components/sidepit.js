const account = {}

export default account