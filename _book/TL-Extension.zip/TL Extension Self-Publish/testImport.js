import * as Stream from 'stream-browserify';
console.log('Stream polyfill:', Stream);
